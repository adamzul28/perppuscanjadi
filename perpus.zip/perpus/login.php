<?php 

    session_start();

	require('koneksi.php');

    if(isset($_POST['login'])){
        $username = $_POST["username"];
        $password = $_POST["password"];

        $result = mysqli_query($conn, "SELECT * FROM user WHERE username = '$username' AND password = '$password'");
        $cek = mysqli_num_rows($result);

        if($cek >0){
            $data = mysqli_fetch_assoc($result);
            if($data['level'] == 'admin'){
                $_SESSION['username'] = $username;
                $_SESSION['level'] = "admin";
                $_SESSION['id'] = $data['id_user'];
                header("Location:admin.php");
            }else if($data['level'] == 'user'){
                $_SESSION['id'] = $data['id_user'];
                $_SESSION['username'] = $username;
                $_SESSION['level'] = "admin";
                header("Location:indexs.php");
            }

        }else{
            header("Location:login.php?pesan=gagal");
        }
    }

    
 ?>

 <!DOCTYPE html>
 <html>
 <head>
 	<meta charset="utf-8">
 	<title>Login Admin</title>
 	<link rel="stylesheet" type="text/css" href="css/style.css">

 </head>
 <body>
 	<div align="center">
 		<h1>Login Page</h1>
 	</div>

    <form method="POST" >
        <section class="base">
            <div>
                <input type="text" name="username" placeholder="Username" autofocus="" required="" autocomplete="off">
            </div>
            <div>
                <input type="password" name="password" placeholder="password" autofocus="" required="">
            </div>
            <div>
                <button class="button-salmon" type="submit" name="login">LOGIN</button>
            </div>
            <div>
                <p>Belum Punya Akun? Daftar <a href="register.php">disini</a></p>
            </div>

            <div>
                <?php 
                    if(isset($_GET['pesan'])){
                        if($_GET['pesan'] == "gagal"){
                            echo "<p>username/password salah</p>";
                        }
                    }
                 ?>
            </div>
        </section>
    </form>
 
 </body>
 </html>