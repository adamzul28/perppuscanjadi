<?php 
	require('koneksi.php');

    if(isset($_POST['input'])){
        $judul_buku = htmlspecialchars($_POST['judul_buku']);
        $pengarang = htmlspecialchars($_POST['pengarang']);
        $penerbit = htmlspecialchars($_POST['penerbit']);
        $isi_buku = htmlspecialchars($_POST['isi_buku']);
        $gambar = $_FILES['gambar']['name'];
        $tmp = $_FILES['gambar']['tmp_name'];
        move_uploaded_file($tmp, "img/".$gambar);

        $result = mysqli_query($conn, "INSERT INTO buku VALUES(null,0,'$judul_buku','$pengarang','$penerbit','$isi_buku','$gambar',10)");

        if(!$result){
                die('query error: '.mysqli_errno($conn).'-'.mysqli_error($conn));
            }else{
                echo 
                "<script>
                    alert('product succesfully uploaded');
                    window.location = 'admin.php';
                </script>";
            }
        
    }
 ?>

 <!DOCTYPE html>
 <html>
 <head>
 	<meta charset="utf-8">
 	<title>Tambah Buku Perpus Online Bina Bangsa</title>
 	<link rel="stylesheet" type="text/css" href="css/style.css">
 </head>
 <body>
 	<div align="center">
 		<h1>Tambah Buku</h1>
 	</div>
 	<form method="POST" enctype="multipart/form-data">
 		<section class="base">
            <div>
                <input type="text" name="judul_buku" placeholder="Judul Buku" autofocus="" required="">
            </div>
            <div>
                <input type="text" name="pengarang" placeholder="Pengarang" autofocus="" required="">
            </div>
            <div>  
                <input type="text" name="penerbit" placeholder="Penerbit" autofocus="" required="">
            </div>
            <div>
                <textarea name="isi_buku" placeholder="Isi Buku" autofocus="" required=""></textarea>
            </div>
            <div>  
                <label>Upload Sampul Buku</label>
                <input type="file" name="gambar">
            </div>
            <div>
                <input class="btn-salmon" type="submit" name="input" value="Upload Buku">
            </div>     
        </section>

 	</form>
 
 </body>
 </html>