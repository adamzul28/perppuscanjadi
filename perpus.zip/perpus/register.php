<?php 
    require('koneksi.php');
    if(isset($_POST['register'])){
        $username = htmlspecialchars($_POST['username']);
        $password = htmlspecialchars($_POST['password']);
        $level = $_POST['level'];

        mysqli_query($conn, "INSERT INTO user VALUES(null,'$username','$password','$level')");

        if(mysqli_affected_rows($conn) >0){
            echo "<script>
            alert('akun berhasil di buat!');
            document.location.href = 'login.php';
            </script>";
        }
    }

 ?>

<!DOCTYPE html>
 <html>
 <head>
 	<meta charset="utf-8">
 	<title>Halaman Registrasi</title>
 	<link rel="stylesheet" type="text/css" href="css/style.css">

 </head>
 <body>
 	<div align="center">
 		<h1>Register Page</h1>
 	</div>

    <form method="POST" >
        <section class="base">
            <div>
                <input type="text" name="username" placeholder="Username" autofocus="" required="" autocomplete="off">
            </div>
            <div>
                <input type="password" name="password" placeholder="password" autofocus="" required="">
            </div>
            <div>
                <select name="level" required>
                    <option value="">Pilih Level</option>
                    <option value="user">User</option>
                    <option value="admin">Admin</option>
                </select>
            </div>
            <div>
                <button class="button-blue" type="submit" name="register">REGISTER</button>
            </div>
            <div>
                <p>Sudah Punya Akun? Login <a href="login.php">disini</a></p>
            </div>

            <div>
                <?php 
                    if(isset($_GET['pesan'])){
                        if($_GET['pesan'] == "gagal"){
                            echo "<p>username/password salah</p>";
                        }
                    }
                 ?>
            </div>
        </section>
    </form>
 
 </body>
 </html>