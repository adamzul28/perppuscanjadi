<?php 

    require('koneksi.php');
    
    $id = $_GET['id'];
    mysqli_query($conn, "UPDATE buku SET flag = 0 WHERE id = $id");

    if(mysqli_affected_rows($conn)>0){
         ?>
        <script type="text/javascript">
          alert('buku berhasil di kembalikan,Terimakasih:)');
          document.location.href = 'buku_saya.php';
        </script>
        <?php
    }

 ?>