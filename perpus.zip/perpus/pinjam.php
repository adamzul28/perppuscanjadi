<?php 
    session_start();
    echo $_SESSION['id'];

    require('koneksi.php');

    $ambil = $conn -> query("SELECT * FROM buku WHERE id = '$_GET[id]'");
    $pecah = $ambil-> fetch_assoc();
    
    $id = $_GET['id'];
    mysqli_query($conn, "UPDATE buku SET flag = 1 WHERE id = $id");

    if(mysqli_affected_rows($conn)>0){
         ?>
        <script type="text/javascript">
          alert('buku berhasil di pinjam,cek di buku saya!');
          document.location.href = 'indexs.php';
        </script>
        <?php
    }else{
        ?>
        <script type="text/javascript">
          alert('anda telah meminjam buku ini sebelumnya!');
          document.location.href = 'indexs.php';
        </script>
        <?php
    }

 ?>