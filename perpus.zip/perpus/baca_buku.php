<?php 
    session_start();
	require('koneksi.php');

    if($_SESSION['level'] == ""){
        header("Location:login.php");
    }

    $ambil = $conn -> query("SELECT * FROM buku WHERE id = '$_GET[id]'");
    $pecah = $ambil-> fetch_assoc();

 ?>

 <!DOCTYPE html>
 <html>
 <head>
 	<meta charset="utf-8">
 	<title>PERPUSTAKAAN ONLINE BINA BANGSA</title>
 	<link rel="stylesheet" type="text/css" href="css/style.css">
 </head>
 <body>
 	<div align="center">
 		<h1>PERPUSTAKAAN ONLINE BINA BANGSA</h1>
 		<h3>hi <?php echo $_SESSION['username']; ?> semangat baca bukunya, silahkan di kembalikan jika telah selesai:)</h3>
 	</div>
    <div class="jarak-text-right"><a href="logout.php">Logout</a></div>

    <div class="jarak-text-left">
        <a href="indexs.php">Pinjam Buku Lain</a>
    </div>
 	
       

 
 </body>
 </html>