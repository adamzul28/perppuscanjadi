<?php 
	
	$conn = new mysqli("localhost","root","","perpus");
	if($conn-> connect_errno){
		echo "gagal terhubung ke mysql: ".$conn-> connect_error;
		exit;
	}else{
		// echo "koneksi sukses";
	}

 ?>