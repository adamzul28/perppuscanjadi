<?php 
    session_start();
	require('koneksi.php');

    if($_SESSION['level'] == ""){
        header("Location:login.php");
    }

    // $ambil = $conn -> query("SELECT * FROM buku WHERE nama_peminjam = '$_SESSION[username]'");
    // $pecah = $ambil-> fetch_assoc();
 ?>

 <!DOCTYPE html>
 <html>
 <head>
 	<meta charset="utf-8">
 	<title>PERPUSTAKAAN ONLINE BINA BANGSA</title>
 	<link rel="stylesheet" type="text/css" href="css/style.css">
 </head>
 <body>
 	<div align="center">
 		<h1>PERPUSTAKAAN ONLINE BINA BANGSA</h1>
 		<h3>hi <?php echo $_SESSION['username']; ?> semangat baca bukunya, silahkan di kembalikan jika telah selesai:)</h3>
 	</div>
    <div class="jarak-text-right"><a href="logout.php">Logout</a></div>

    <div class="jarak-text-left">
        <a href="indexs.php">Pinjam Buku Lain</a>
    </div>
 	<table class="jarak">
        <caption style="color: gray; text-align: left;">Table Daftar Peminjaman Saya</caption>
 		<thead>
 			<tr>
 				<th>No</th>
                <th><?php echo $_SESSION['id']; ?></th>
 				<th>Gambar</th>
 				<th>Judul Buku</th>
 				<th>Pengarang</th>
 				<th>penerbit</th>
 				<th>Isi Buku</th>
 				<th colspan="2">Option</th>
 			</tr>
 		</thead>

 		<tbody>
            <!-- <p><?php echo $pecah['id']; ?></p> -->
            <?php 
                $buku = mysqli_query($conn, "SELECT * FROM buku INNER JOIN user WHERE id_user = '$_SESSION[id]' AND flag = 1");
                $no = 1;
                while($row = mysqli_fetch_assoc($buku)){
             ?>
 			<tr>
                <td><?php echo $no; ?></td>
                <td><img style="width: 50px;" src="img/<?php echo $row['gambar']; ?>"></td>
 				<td><?php echo $row['judul_buku']; ?></td>
                <td><?php echo $row['pengarang']; ?></td>
                <td><?php echo $row['penerbit']; ?></td>
                <td><?php echo substr($row['isi_buku'],0,20); ?>...</td>
                <td><a href="baca_buku.php?id=<?php echo $row['id']; ?>">Baca Buku</a></td>
                <td><a class="blue" href="kembalikan.php?id=<?php echo $row['id']; ?>">Kembalikan Buku Ini</a></td>

 			</tr>
            <?php 
                $no++;
                }
             ?>
 		</tbody>
 	</table>

 
 </body>
 </html>