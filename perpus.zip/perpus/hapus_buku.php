<?php 

	require('koneksi.php');

	$id = $_GET['id'];
	mysqli_query($conn,"DELETE FROM buku WHERE id = $id");

	if(mysqli_affected_rows($conn)>0){
		 ?>
        <script type="text/javascript">
          alert('buku berhasil di hapus');
          document.location.href = 'admin.php';
        </script>
      	<?php
	}
 ?>