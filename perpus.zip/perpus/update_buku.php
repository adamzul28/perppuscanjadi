<?php 
    session_start();
    if($_SESSION['level'] == ""){
        header("Location:login.php");
    }

    require('koneksi.php');

    $ambil = $conn -> query("SELECT * FROM buku WHERE id = '$_GET[id]'");
    $pecah = $ambil-> fetch_assoc();

    if(isset($_POST['update'])){
        $judul_buku = htmlspecialchars($_POST['judul_buku']);
        $pengarang = htmlspecialchars($_POST['pengarang']);
        $penerbit = htmlspecialchars($_POST['penerbit']);
        $isi_buku = htmlspecialchars($_POST['isi_buku']);
        $gambar = $_FILES['gambar']['name'];
        $tmp = $_FILES['gambar']['tmp_name'];

        if(!empty($tmp)){
            move_uploaded_file($tmp, "img/".$gambar);
            $result = $conn->query("UPDATE buku SET judul_buku = '$judul_buku', pengarang = '$pengarang', penerbit='$penerbit', isi_buku='$isi_buku', gambar='$gambar' WHERE id = '$_GET[id]'");
        }else{
            $result = $conn->query("UPDATE buku SET judul_buku = '$judul_buku', pengarang = '$pengarang', penerbit='$penerbit', isi_buku='$isi_buku' WHERE id = '$_GET[id]'");
        }

        if(!$result){
                die('query error: '.mysqli_errno($conn).'-'.mysqli_error($conn));
            }else{
                 ?>
                <script type="text/javascript">
                  alert('buku berhasil di update');
                  document.location.href = 'admin.php';
                </script>
                <?php
            }
    }

 ?>

 <!DOCTYPE html>
 <html>
 <head>
 	<meta charset="utf-8">
 	<title>Update Buku Perpus Online Bina Bangsa</title>
 	<link rel="stylesheet" type="text/css" href="css/style.css">
 </head>
 <body>
 	<div align="center">
 		<h1>Update Buku</h1>
 	</div>
 	<form method="POST" enctype="multipart/form-data">
 		<section class="base">
            <div>
                <input type="text" name="judul_buku" placeholder="Judul Buku" autofocus="" required="" value="<?php echo $pecah['judul_buku']; ?>">
            </div>
            <div>
                <input type="text" name="pengarang" placeholder="Pengarang" autofocus="" required="" value="<?php echo $pecah['pengarang']; ?>">
            </div>
            <div>  
                <input type="text" name="penerbit" placeholder="Penerbit" autofocus="" required="" value="<?php echo $pecah['penerbit']; ?>">
            </div>
            <div>
                <textarea name="isi_buku" placeholder="Isi Buku" autofocus="" required=""><?php echo $pecah['isi_buku']; ?></textarea>
            </div>
            <div>  

                <label>Update Sampul Buku</label>
                <img style="width: 50px" src="img/<?php echo $pecah['gambar']; ?>">
                <input type="file" name="gambar">
            </div>
            <div>
                <input class="btn-salmon" type="submit" name="update" value="Update Buku">
            </div>     
        </section>

 	</form>
 
 </body>
 </html>