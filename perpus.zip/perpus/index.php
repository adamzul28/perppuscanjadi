<?php 
    
    require('koneksi.php');


 ?>

 <!DOCTYPE html>
 <html>
 <head>
    <meta charset="utf-8">
    <title>PERPUSTAKAAN ONLINE BINA BANGSA</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
 </head>
 <body>
    <div align="center">
        <h1>PERPUSTAKAAN ONLINE BINA BANGSA</h1>
        <p>Silahkan Mendaftar Dan Login Untuk Meminjam Buku</p>
    </div>
    <div class="jarak-text-right"><a href="login.php">LOGIN</a></div>

    <table class="jarak">
        <caption style="color: gray; text-align: left;">Table Daftar Buku</caption>
        <thead>
            <tr>
                <th>No</th>
                <th>Gambar</th>
                <th>Judul Buku</th>
                <th>Pengarang</th>
                <th>penerbit</th>
                <th>Isi Buku</th>
            </tr>
        </thead>

        <tbody>
            <?php 
                $buku = mysqli_query($conn, "SELECT * FROM buku ORDER BY ID ASC");
                $no = 1;
                while($row = mysqli_fetch_assoc($buku)){
             ?>
            <tr>
                <td><?php echo $no; ?></td>
                <td><img style="width: 50px;" src="img/<?php echo $row['gambar']; ?>"></td>
                <td><?php echo $row['judul_buku']; ?></td>
                <td><?php echo $row['pengarang']; ?></td>
                <td><?php echo $row['penerbit']; ?></td>
                <td><?php echo substr($row['isi_buku'],0,20); ?>...</td>
            </tr>
            <?php 
                $no++;
                }
             ?>
        </tbody>
    </table>

 
 </body>
 </html>